﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAalborgCamping
{
	public class SmallBungalow : CampGroundUnit
	{

		public SmallBungalow(int nof_items) 
			:base(nof_items)
		{

		}
	}
}
